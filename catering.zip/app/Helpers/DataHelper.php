<?php

function intakeYear() {
	return [
		2019,2020,2021,2022,2023,2024,2025
	];
}
