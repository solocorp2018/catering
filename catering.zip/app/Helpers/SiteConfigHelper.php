<?php


function siteName() {	
    return "M R Grandson Caters";
}

function logo() {
	return asset('packa/logo/2.png');
	
}

function favicon() {
	
    return  asset('packa/logo/favicon-2.png');
}

function userimage() {
	return asset('packa/theme/images/users/noimage.jpg');
	
}

function gpayNumber() {
	return "xxxxxxxxxxxx";
}

function phonePayNumber() {
	return "xxxxxxxxxxxx";
}

function supportnumber() {
	return "+919047531591 ";
}