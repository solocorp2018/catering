<?php

namespace App\Http\Controllers\Admin;

use App\Models\Complimentary;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ComplimentaryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Complimentary  $complimentary
     * @return \Illuminate\Http\Response
     */
    public function show(Complimentary $complimentary)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Complimentary  $complimentary
     * @return \Illuminate\Http\Response
     */
    public function edit(Complimentary $complimentary)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Complimentary  $complimentary
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Complimentary $complimentary)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Complimentary  $complimentary
     * @return \Illuminate\Http\Response
     */
    public function destroy(Complimentary $complimentary)
    {
        //
    }
}
