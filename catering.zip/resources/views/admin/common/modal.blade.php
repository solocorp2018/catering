<div class="card slide-modal right-sidebar">
    <div><a onclick="closePopup();"><i class="ti-close"></i></a></div>
    <div id="popupForm"></div>
</div>

      
   