<footer class="pt-4 pb-4 text-center">
         <div class="container">
            <p class="mt-0 mb-0">© Copyright 2021 Aegis. All Rights Reserved</p>
            <small class="mt-0 mb-0"> Developed by
            <a class="text-primary" target="_blank" href="#">Aegiiz Technologies</a>
            </small>
         </div>
      </footer>