<footer class="pt-4 pb-4 text-center">
         <div class="container">
            <p class="mt-0 mb-0">© Copyright 2021 MR Grandson Caters. All Rights Reserved</p>
            <small class="mt-0 mb-0"> Developed by
            <a class="text-primary" target="_blank" href="http://aegiiz.com">Aegiiz Technologies</a>
            </small>
         </div>
      </footer>