<h4 class="font-weight-bold mt-0 mb-4">Past Orders</h4>
<div class="bg-white card mb-4 order-list shadow-sm">
   <div class="gold-members p-4">
      <a href="#">
         <div class="media">
            
            <div class="media-body">
               <span class="float-right text-info">Delivered on Mon, JAN 12, 7:18 PM <i class="icofont-check-circled text-success"></i></span>
               
      <p class="text-gray mb-1"><i class="icofont-location-arrow"></i> Tidel Park, Coimbatore - 641141 
      </p>
      <p class="text-gray mb-3"><i class="icofont-list"></i> ORDER #25102589748 <i class="icofont-clock-time ml-2"></i> Mon, Nov 12, 6:26 PM</p>
      <p class="text-dark">Idly x 5, Ghee Roast x 2
      </p>
      <hr>
      <div class="float-right">
      <a class="btn btn-sm btn-outline-primary" href="#"><i class="icofont-headphone-alt"></i> HELP</a>
      </div>
      <p class="mb-0 text-black text-primary pt-2"><span class="text-black font-weight-bold"> Total Paid:</span> 150 INR
      </p>
      </div>
      </div>
      </a>
   </div>
</div>

<div class="bg-white card mb-4 order-list shadow-sm">
   <div class="gold-members p-4">
      <a href="#">
         <div class="media">
            
            <div class="media-body">
               <span class="float-right text-info">Delivered on Mon, JAN 18, 10:00 AM <i class="icofont-check-circled text-success"></i></span>
               
      <p class="text-gray mb-1"><i class="icofont-location-arrow"></i> Tidel Park, Coimbatore - 641141 
      </p>
      <p class="text-gray mb-3"><i class="icofont-list"></i> ORDER #25102589748 <i class="icofont-clock-time ml-2"></i> Mon, Nov 12, 6:26 PM</p>
      <p class="text-dark">Idly x 5, Pongal x 1
      </p>
      <hr>
      <div class="float-right">
      <a class="btn btn-sm btn-outline-primary" href="#"><i class="icofont-headphone-alt"></i> HELP</a>
      </div>
      <p class="mb-0 text-black text-primary pt-2"><span class="text-black font-weight-bold"> Total Paid:</span> 150 INR
      </p>
      </div>
      </div>
      </a>
   </div>
</div>
