<?php

return [

	'app_name' => 'M R Grandson Caters',
	'weblink' => 'mrgrandsoncaters.in',
	'allowed_item_limit_for_menu' => 10,

];
