<?php

return [

	'allowed_item_limit_for_menu' => 10,
];
